library(testthat)
library(mcglm)

test_check("mcglm")
